import React from "react";
import { FaDumbbell, FaFire, FaChartLine } from "react-icons/fa";

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="logo">FitTrack</div>
      <nav>
        <a href="#"><FaDumbbell /> Workouts</a>
        <a href="#"><FaFire /> Calories</a>
        <a href="#"><FaChartLine /> Progress</a>
      </nav>
    </aside>
  );
}










