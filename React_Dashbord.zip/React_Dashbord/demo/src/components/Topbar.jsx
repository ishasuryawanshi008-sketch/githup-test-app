import React from "react";

export default function Topbar() {
  return (
    <header className="topbar">
      <h1>Fitness Progress Dashboard</h1>
      <div className="profile">
        <span className="profile-name">Welcome, Isha</span>
      </div>
    </header>
  );
}







