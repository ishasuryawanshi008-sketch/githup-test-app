import React from "react";

export default function StatCard({ title, value, change }) {
  return (
    <div className="stat-card">
      <h3>{title}</h3>
      <p className="value">{value}</p>
      <span>{change}</span>
    </div>
  );
}







