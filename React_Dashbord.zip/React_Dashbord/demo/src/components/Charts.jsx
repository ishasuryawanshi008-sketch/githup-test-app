import React from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";

const data = [
  { name: "Mon", workouts: 3, calories: 500 },
  { name: "Tue", workouts: 2, calories: 450 },
  { name: "Wed", workouts: 4, calories: 700 },
  { name: "Thu", workouts: 3, calories: 600 },
  { name: "Fri", workouts: 5, calories: 800 },
  { name: "Sat", workouts: 2, calories: 400 },
  { name: "Sun", workouts: 1, calories: 250 },
];

export default function Charts() {
  return (
    <ResponsiveContainer width="100%" height={400}>
      <ComposedChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis dataKey="name" tick={{ fill: "#475569", fontSize: 14 }} />
        <YAxis tick={{ fill: "#475569", fontSize: 14 }} />
        <Tooltip
          contentStyle={{ background: "#fff", borderRadius: "10px", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}
        />
        <Legend />
        
        {/* Bar for Workouts */}
        <Bar dataKey="workouts" barSize={40} fill="#4f46e5" radius={[8, 8, 0, 0]} />
        
        {/* Line for Calories */}
        <Line
          type="monotone"
          dataKey="calories"
          stroke="#ec4899"
          strokeWidth={3}
          dot={{ r: 6, fill: "#ec4899" }}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}









