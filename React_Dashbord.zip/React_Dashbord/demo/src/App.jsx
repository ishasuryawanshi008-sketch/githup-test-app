import React from "react";
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import StatCard from "./components/StatCard";
import Charts from "./components/Charts";

export default function App() {
  return (
    <div className="dashboard">
      <Sidebar />
      <main className="main">
        <Topbar />

        {/* Stats Section */}
        <section className="stats">
          <StatCard title="Workouts Completed" value="42" change="+5 this week" />
          <StatCard title="Calories Burned" value="12,500" change="+1,200 this week" />
          <StatCard title="Goals Achieved" value="8/10" change="On Track" />
          <StatCard title="Active Days" value="22" change="+3 this month" />
        </section>

        {/* Charts */}
        <section className="charts">
          <Charts />
        </section>
      </main>
    </div>
  );
}















